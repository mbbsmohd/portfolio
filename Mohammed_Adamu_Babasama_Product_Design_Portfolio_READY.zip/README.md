# Mohammed Adamu Babasama — Product Design Portfolio

## Ready to publish
Open `index.html` in a browser to preview the portfolio.

## What is included
- Product-design positioning
- Four portfolio project areas
- Three detailed case studies
- End-to-end UX process
- Evidence-based fintech metrics
- Skills, contact and responsive layout

## Important
The portfolio deliberately avoids invented user-testing or business-impact numbers. Replace or add metrics only when you have evidence from actual projects.

## Publishing options
Upload `index.html` to GitHub Pages, Netlify, Vercel, or any normal web host.
